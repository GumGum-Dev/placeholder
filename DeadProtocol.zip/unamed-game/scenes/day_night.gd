
@tool
extends CanvasModulate

@export_range(0.0, 24.0, 0.25) var time_of_day: float = 12.0:
	set(value):
		time_of_day = value
		update_lighting()

@export var directional_light: DirectionalLight2D

func _ready() -> void:
	update_lighting()


func update_lighting() -> void:
	var t := fposmod(time_of_day, 24.0)

	# Time, ambient color, sunlight color, sunlight energy
	var hours := [0.0, 4.5, 6.0, 7.5, 10.0, 14.0, 16.5, 18.0, 19.5, 21.0, 24.0]
	var ambient_colors := [
		Color("#080D18"),
		Color("#11192A"),
		Color("#514052"),
		Color("#B47C69"),
		Color("#929F9B"),
		Color("#B9C1B5"),
		Color("#C5A18A"),
		Color("#B87962"),
		Color("#514052"),
		Color("#171D30"),
		Color("#080D18")
	]
	var sun_colors := [
		Color("#263858"),
		Color("#394766"),
		Color("#E49B76"),
		Color("#FFD4A1"),
		Color("#FFF1D6"),
		Color("#FFF4DF"),
		Color("#FFCB91"),
		Color("#F08A65"),
		Color("#73566F"),
		Color("#303D60"),
		Color("#263858")
	]
	var sun_energies := [
		0.0, 0.0, 0.15, 0.45, 0.75, 0.8, 0.55, 0.25, 0.05, 0.0, 0.0
	]

	var index := 0
	for i in range(hours.size() - 1):
		if t >= hours[i] and t <= hours[i + 1]:
			index = i
			break

	var span: float = hours[index + 1] - hours[index]
	var blend: float = (t - hours[index]) / span
	blend = smoothstep(0.0, 1.0, blend)

	color = ambient_colors[index].lerp(
		ambient_colors[index + 1], blend
	)

	if directional_light:
		directional_light.color = sun_colors[index].lerp(
			sun_colors[index + 1], blend
		)
		directional_light.energy = lerpf(
			sun_energies[index],
			sun_energies[index + 1],
			blend
		)
		directional_light.rotation = deg_to_rad(t * 15.0 - 180.0)
