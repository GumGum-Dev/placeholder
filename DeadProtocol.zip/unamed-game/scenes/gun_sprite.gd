extends Sprite2D

@export var pushback_distance: float = 20.0
@export var spring_strength: float = 180.0
@export var spring_damping: float = 20.0

var gun_pivot: Node2D
var wall_check: RayCast2D
var gun_collision: CollisionPolygon2D

var start_position: Vector2
var collision_start_global_position: Vector2

var pushback: float = 0.0
var spring_velocity: float = 0.0


func _ready() -> void:
	gun_pivot = get_parent() as Node2D

	wall_check = gun_pivot.get_node_or_null(
		"WallCheck"
	) as RayCast2D

	gun_collision = gun_pivot.find_child(
		"GunCollision", true, false
	) as CollisionPolygon2D

	if wall_check == null:
		push_error("GunSprite: WallCheck was not found under Gunpivot point.")
		set_physics_process(false)
		return

	if gun_collision == null:
		push_error("GunSprite: GunCollision was not found under Gunpivot point.")
		set_physics_process(false)
		return

	start_position = position
	collision_start_global_position = gun_collision.global_position

	wall_check.enabled = true


func _physics_process(delta: float) -> void:
	wall_check.force_raycast_update()

	var target_pushback: float = 0.0

	if wall_check.is_colliding():
		target_pushback = pushback_distance

	var acceleration := (
		(target_pushback - pushback) * spring_strength
		- spring_velocity * spring_damping
	)

	spring_velocity += acceleration * delta
	pushback += spring_velocity * delta
	pushback = clampf(pushback, 0.0, pushback_distance)

	# Move the gun backward along its own local X-axis.
	position = start_position - Vector2(pushback, 0.0)

	# Move the custom polygon backward along the pivot's direction.
	var backward_direction := -gun_pivot.global_transform.x.normalized()
	gun_collision.global_position = (
		collision_start_global_position
		+ backward_direction * pushback
	)
