extends Node2D

@export_group("Player")
@export var player_path: NodePath = NodePath("../Player")

@export_group("Vision")
@export var vision_radius: float = 600.0
@export_range(32, 128, 1) var ray_count: int = 120
@export_flags_2d_physics var wall_collision_mask: int = 1

@export_group("Darkness")
@export_range(0.0, 1.0) var darkness_alpha: float = 0.97

@onready var overlay: ColorRect = $CanvasLayer/ColorRect

var player: CharacterBody2D
var vision_material: ShaderMaterial


func _ready() -> void:
	player = get_node_or_null(player_path) as CharacterBody2D

	if player == null:
		push_error("VisionSystem: Player not found. Check player_path.")
		return

	vision_material = overlay.material as ShaderMaterial

	if vision_material == null:
		push_error("VisionSystem: ColorRect needs a ShaderMaterial.")
		return

	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.color = Color.WHITE

	vision_material = vision_material.duplicate() as ShaderMaterial
	overlay.material = vision_material

	vision_material.set_shader_parameter(
		"darkness_alpha",
		darkness_alpha
	)

	update_vision()


func _process(_delta: float) -> void:
	update_vision()


func update_vision() -> void:
	if player == null or vision_material == null:
		return

	var viewport_size := get_viewport_rect().size

	if viewport_size.x <= 0.0 or viewport_size.y <= 0.0:
		return

	var canvas_transform := get_viewport().get_canvas_transform()
	var space_state := get_world_2d().direct_space_state
	var origin := player.global_position
	var count := clampi(ray_count, 32, 128)

	var query := PhysicsRayQueryParameters2D.new()
	query.from = origin
	query.collision_mask = wall_collision_mask
	query.exclude = [player.get_rid()]

	var shader_points := PackedVector2Array()
	shader_points.resize(128)

	for i in range(count):
		var angle := TAU * float(i) / float(count)
		var direction := Vector2.RIGHT.rotated(angle)
		var endpoint := origin + direction * vision_radius

		query.to = endpoint

		var hit := space_state.intersect_ray(query)

		if not hit.is_empty():
			endpoint = hit["position"]

		var screen_point := canvas_transform * endpoint

		shader_points[i] = Vector2(
			screen_point.x / viewport_size.x,
			screen_point.y / viewport_size.y
		)

	for i in range(count, 128):
		shader_points[i] = Vector2.ZERO

	vision_material.set_shader_parameter(
		"vision_points",
		shader_points
	)

	vision_material.set_shader_parameter(
		"vision_point_count",
		count
	)
