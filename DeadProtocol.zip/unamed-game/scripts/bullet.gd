extends Area2D

@export var speed: float = 1200.0
@export var lifetime: float = 2.0
@export_group("Bullet Spread")
@export var standing_still_spread: float = 1.0
@export var moving_spread: float = 8.0
@export var max_spread: float = 15.0

var direction: Vector2 = Vector2.RIGHT


func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _physics_process(delta: float) -> void:
	var start := global_position
	var finish := start + direction * speed * delta

	var query := PhysicsRayQueryParameters2D.create(start, finish)
	query.collision_mask = collision_mask
	query.exclude = [get_rid()]

	var hit := get_world_2d().direct_space_state.intersect_ray(query)

	if not hit.is_empty():
		queue_free()
		return

	global_position = finish

	lifetime -= delta
	if lifetime <= 0.0:
		queue_free()


func _on_body_entered(_body: Node2D) -> void:
	queue_free()


func _draw() -> void:
	draw_circle(Vector2.ZERO, 1.0, Color.RED)
