
extends Camera2D

@export var mouse_offset_distance: float = 80.0
@export var smoothness: float = 4.0

func _process(delta: float) -> void:
	var viewport_size := get_viewport_rect().size
	var screen_center := viewport_size / 2.0
	var mouse_position := get_viewport().get_mouse_position()

	var mouse_direction := (mouse_position - screen_center) / screen_center
	mouse_direction.x = clampf(mouse_direction.x, -1.0, 1.0)
	mouse_direction.y = clampf(mouse_direction.y, -1.0, 1.0)

	var target_offset := mouse_direction * mouse_offset_distance
	offset = offset.lerp(
		target_offset,
		1.0 - exp(-smoothness * delta)
	)
