extends Camera2D

@export var smooth_speed: float = 10.0
@export var look_ahead: float = 15.0

@onready var player: Node2D = get_parent() as Node2D


func _process(delta: float) -> void:
	if not is_instance_valid(player):
		return

	var mouse_direction := (
		get_global_mouse_position() - player.global_position
	).normalized()

	var target_position := (
		player.global_position + mouse_direction * look_ahead
	)

	global_position = global_position.lerp(
		target_position,
		1.0 - exp(-smooth_speed * delta)
	)
