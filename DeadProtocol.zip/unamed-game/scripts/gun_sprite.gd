
extends Sprite2D

@export var pistol: Texture2D
@export var rifle: Texture2D
@export var shotgun: Texture2D
@export var smg: Texture2D
@export var sniper_rifle: Texture2D

var current_gun: int = 1


func _ready() -> void:
	equip_gun(current_gun)

func _process(_delta: float) -> void:
	if Input.is_action_just_pressed("k1"):
		equip_gun(1)
	elif Input.is_action_just_pressed("k2"):
		equip_gun(2)
	elif Input.is_action_just_pressed("k3"):
		equip_gun(3)
	elif Input.is_action_just_pressed("k4"):
		equip_gun(4)
	elif Input.is_action_just_pressed("k5"):
		equip_gun(5)

func equip_gun(slot: int) -> void:
	current_gun = slot

	match current_gun:
		1:
			texture = pistol
		2:
			texture = rifle
		3:
			texture = shotgun
		4:
			texture = smg
		5:
			texture = sniper_rifle
