
extends Node2D

@export var bullet_scene: PackedScene

@export_group("Bullet Settings")
@export var bullet_speed: float = 1200.0
@export var bullet_lifetime: float = 2.0

@export_group("Fire Rates")
@export var pistol_fire_rate: float = 3.0
@export var rifle_fire_rate: float = 8.0
@export var shotgun_fire_rate: float = 1.0
@export var smg_fire_rate: float = 12.0
@export var sniper_fire_rate: float = 0.7

@export_group("Bullet Spread")
@export var standing_still_spread: float = 1.0
@export var moving_spread: float = 8.0
@export var aiming_spread_multiplier: float = 0.4
@export var max_spread: float = 15.0

@onready var gun_pivot: Node2D = $"Gunpivot point"
@onready var gun_sprite: Sprite2D = $"Gunpivot point/GunSprite"
@onready var muzzle_pistol: Marker2D = $"Gunpivot point/GunSprite/MuzzlePistol"
@onready var muzzle_rifle: Marker2D = $"Gunpivot point/GunSprite/MuzzleRifle"
@onready var muzzle_shotgun: Marker2D = $"Gunpivot point/GunSprite/MuzzleShotgun"
@onready var muzzle_smg: Marker2D = $"Gunpivot point/GunSprite/MuzzleSMG"
@onready var muzzle_sniper: Marker2D = $"Gunpivot point/GunSprite/MuzzleSniper"

var fire_timer: float = 0.0
var player: CharacterBody2D


func _ready() -> void:
	player = get_parent() as CharacterBody2D


func _process(delta: float) -> void:
	fire_timer = maxf(0.0, fire_timer - delta)
	gun_pivot.look_at(get_global_mouse_position())

	if Input.is_action_pressed("shoot") and fire_timer <= 0.0:
		shoot()


func shoot() -> void:
	if bullet_scene == null:
		push_error("Assign your bullet scene in the GunSystem Inspector.")
		return

	var gun_id := int(gun_sprite.get("current_gun"))
	var muzzle := get_current_muzzle(gun_id)
	var fire_rate := get_current_fire_rate(gun_id)

	if muzzle == null or fire_rate <= 0.0:
		return

	fire_timer = 1.0 / fire_rate

	var bullet = bullet_scene.instantiate()
	get_tree().current_scene.add_child(bullet)
	bullet.global_position = muzzle.global_position

	var movement_amount := 0.0
	if player != null:
		movement_amount = clampf(player.velocity.length() / 100.0, 0.0, 1.0)

	var spread := lerpf(standing_still_spread, moving_spread, movement_amount)

	if Input.is_action_pressed("aim"):
		spread *= aiming_spread_multiplier

	spread = minf(spread, max_spread)
	var random_angle := deg_to_rad(randf_range(-spread, spread))

	bullet.direction = Vector2.RIGHT.rotated(muzzle.global_rotation + random_angle)
	bullet.speed = bullet_speed
	bullet.lifetime = bullet_lifetime


func get_current_muzzle(gun_id: int) -> Marker2D:
	match gun_id:
		1:
			return muzzle_pistol
		2:
			return muzzle_rifle
		3:
			return muzzle_shotgun
		4:
			return muzzle_smg
		5:
			return muzzle_sniper

	return null


func get_current_fire_rate(gun_id: int) -> float:
	match gun_id:
		1:
			return pistol_fire_rate
		2:
			return rifle_fire_rate
		3:
			return shotgun_fire_rate
		4:
			return smg_fire_rate
		5:
			return sniper_fire_rate

	return pistol_fire_rate
