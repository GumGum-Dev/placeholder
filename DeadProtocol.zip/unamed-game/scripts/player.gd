
extends CharacterBody2D

@export_group("Movement")
@export var speed: float = 25.0
@export var sprint_multiplier: float = 2.5
@export var acceleration: float = 420.0
@export var deceleration: float = 800.0
@export var direction_change_rate: float = 300.0

@export_group("Weight")
@export var weight: float = 15.0
@export var max_weight: float = 40.0

@export_group("Stamina")
@export var max_stamina: float = 100.0
@export var stamina_drain: float = 25.0
@export var stamina_recovery: float = 18.0

@export_group("Aiming")
@export_range(0.1, 1.0) var aiming_speed_multiplier: float = 0.6
@export_range(0.1, 1.0) var aiming_turn_multiplier: float = 0.5

@export_group("Flashlight")
@export var FLASHLIGHT: bool = true

var stamina: float = 100.0
var aiming: bool = false

@onready var player_sprite: Sprite2D = $Sprite2D
@onready var collision_shape: CollisionShape2D = $PlayerCollision
@onready var flashlight: PointLight2D = get_node_or_null("Sprite2D/PointLight2D") as PointLight2D


func _ready() -> void:
	stamina = max_stamina
	update_flashlight()

func _process(_delta: float) -> void:
	var mouse_pos := get_global_mouse_position()
	player_sprite.look_at(mouse_pos)
	collision_shape.look_at(mouse_pos)


func _physics_process(delta: float) -> void:
	aiming = Input.is_action_pressed("aim")

	if Input.is_action_just_pressed("Flashlight"):
		FLASHLIGHT = not FLASHLIGHT
		update_flashlight()

	var direction := Input.get_vector("left", "right", "up", "down")

	var weight_factor := 0.0
	if max_weight > 0.0:
		weight_factor = clampf(weight / max_weight, 0.0, 1.5)

	var current_speed := speed * (1.0 - minf(weight_factor, 1.0) * 0.5)

	if aiming:
		current_speed *= aiming_speed_multiplier

	var sprinting := (
		Input.is_action_pressed("sprint")
		and stamina > 0.0
		and direction != Vector2.ZERO
	)

	if sprinting:
		current_speed *= sprint_multiplier
		stamina = maxf(
			0.0,
			stamina - stamina_drain * (1.0 + weight_factor) * delta
		)
	else:
		stamina = minf(
			max_stamina,
			stamina + stamina_recovery * delta
		)

	if weight > max_weight:
		current_speed *= maxf(
			0.5,
			1.0 - (weight_factor - 1.0)
		)

	var target_velocity := direction * current_speed

	if direction == Vector2.ZERO:
		velocity = velocity.move_toward(
			Vector2.ZERO,
			deceleration * delta
		)
	else:
		var reversing := velocity.dot(direction) < 0.0
		var rate := direction_change_rate if reversing else acceleration

		if aiming:
			rate *= aiming_turn_multiplier

		velocity = velocity.move_toward(
			target_velocity,
			rate * delta
		)

	move_and_slide()


func update_flashlight() -> void:
	if flashlight != null:
		flashlight.visible = FLASHLIGHT
