
extends CharacterBody2D

@export_group("Movement")
@export var speed: float = 25.0
@export var sprint_multiplier: float = 2.5
@export var acceleration: float = 420.0
@export var deceleration: float = 800.0
@export var direction_change_rate: float = 300

@export_group("attachments")
@export var FLASHLIGHT: bool = true	

@export_group("Weight")
@export var weight: float = 15.0
@export var max_weight: float = 40.0

@export_group("Stamina")
@export var max_stamina: float = 100.0
@export var stamina_drain: float = 25.0
@export var stamina_recovery: float = 18.0

var stamina: float = 100.0
var gun_pivot: Node2D


func _ready() -> void:
	stamina = max_stamina
	gun_pivot = get_parent().get_node_or_null("Gunpivot point") as Node2D


func _process(_delta: float) -> void:
	if gun_pivot != null:
		gun_pivot.global_position = global_position
		gun_pivot.look_at(get_global_mouse_position())


func _physics_process(delta: float) -> void:
	var direction := Input.get_vector(
		"left", "right", "up", "down"
	)

	var weight_factor := clampf(weight / max_weight, 0.0, 1.5)
	var current_speed := speed * (
		1.0 - minf(weight_factor, 1.0) * 0.5
	)

	var sprinting := (
		Input.is_action_pressed("sprint")
		and stamina > 0.0
		and direction != Vector2.ZERO
	)

	if Input.is_action_just_pressed("Flashlight"):
		FLASHLIGHT = !FLASHLIGHT

	if FLASHLIGHT == true:
		$Sprite2D/PointLight2D.energy = 0.0
	if FLASHLIGHT == false:
		$Sprite2D/PointLight2D.energy = 1.0

	if sprinting:
		current_speed *= sprint_multiplier
		stamina = maxf(
			0.0,
			stamina - stamina_drain * (1.0 + weight_factor) * delta
		)
	else:
		stamina = minf(
			max_stamina,
			stamina + stamina_recovery * delta
		)

	if weight > max_weight:
		current_speed *= maxf(
			0.5,
			1.0 - (weight_factor - 1.0)
		)

	var target_velocity := direction * current_speed

	if direction == Vector2.ZERO:
		velocity = velocity.move_toward(
			Vector2.ZERO,
			deceleration * delta
		)
	else:
		var reversing := velocity.dot(direction) < 0.0
		var rate := direction_change_rate if reversing else acceleration

		velocity = velocity.move_toward(
			target_velocity,
			rate * delta
		)

	move_and_slide()
